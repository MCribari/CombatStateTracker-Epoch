local UnitAffectingCombat = UnitAffectingCombat

local TargetCombatStateFrame = CreateFrame("Frame", nil, TargetFrame)
local FocusCombatStateFrame = CreateFrame("Frame", nil, FocusFrame)

for _, f in ipairs({TargetCombatStateFrame, FocusCombatStateFrame}) do
	f:SetPoint("RIGHT", 0, 5)
	f:SetSize(25, 25)
	f.t = f:CreateTexture()
	f.t:SetAllPoints()
	f.t:SetTexture("Interface\\Icons\\ability_dualwield")
end

local THROTTLE_TIME = 0.25

local TargetEventHandler = CreateFrame("Frame")

TargetEventHandler:RegisterEvent("PLAYER_TARGET_CHANGED")

TargetEventHandler:SetScript("OnEvent", function(self)
	if UnitExists("target") then	
		self.elapsedTime = THROTTLE_TIME
		
		self:SetScript("OnUpdate", function(self, elapsed)
			self.elapsedTime = self.elapsedTime + elapsed
			
			if THROTTLE_TIME > self.elapsedTime then return end

			if UnitAffectingCombat("target") then
				TargetCombatStateFrame:Show()
			else
				TargetCombatStateFrame:Hide()
			end
			
			self.elapsedTime = 0
		end)
	else	
		self:SetScript("OnUpdate", nil)
	end
end)

local FocusEventHandler = CreateFrame("Frame")

FocusEventHandler:RegisterEvent("PLAYER_FOCUS_CHANGED")

FocusEventHandler:SetScript("OnEvent", function(self)
	if UnitExists("focus") then
		self.elapsedTime = THROTTLE_TIME
		
		self:SetScript("OnUpdate", function(self, elapsed)
			self.elapsedTime = self.elapsedTime + elapsed
			
			if THROTTLE_TIME > self.elapsedTime then return end
			
			if UnitAffectingCombat("focus") then
				FocusCombatStateFrame:Show()
			else
				FocusCombatStateFrame:Hide()
			end
			
			self.elapsedTime = 0
		end)
	else
		self:SetScript("OnUpdate", nil)
	end
end)